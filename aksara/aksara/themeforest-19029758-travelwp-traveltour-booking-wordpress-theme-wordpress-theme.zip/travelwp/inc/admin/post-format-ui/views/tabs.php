<div id="bws-post-formats-ui-tabs" class="bws-ui-nav">
	<ul class="clearfix">
<?php

foreach ($post_formats as $format) {
	$class = ($format == $current_post_format || (empty($current_post_format) && $format == 'standard') ? 'current' : '');
	
	if ($format == 'standard') {
		$format_string = esc_html__('Standard', 'travelwp');
		$format_hash = 'post-format-0';
	}
	else {
		$format_string = get_post_format_string($format);
		$format_hash = 'post-format-'.$format;
	}
	echo '<li><a class="post-format-icon post-format-'.esc_attr($format).(!empty($class) ? ' '.esc_attr($class).'' : '').'" href="#'.esc_attr($format_hash).'">'.esc_html($format_string).'</a></li>';
}

?>
	</ul>
</div>